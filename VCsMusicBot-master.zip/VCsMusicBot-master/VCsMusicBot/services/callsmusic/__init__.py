from VCsMusicBot.services.queues import queues
from VCsMusicBot.services.callsmusic.callsmusic import pytgcalls, run

__all__ = ["queues", "pytgcalls", "run"]
