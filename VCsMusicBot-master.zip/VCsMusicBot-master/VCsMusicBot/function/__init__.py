from VCsMusicBot.function.admins import admins
from VCsMusicBot.function.admins import get
from VCsMusicBot.function.admins import set

__all__ = ["set", "get", "admins"]
